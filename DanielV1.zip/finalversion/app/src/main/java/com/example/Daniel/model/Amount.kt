package com.example.Daniel.model

data class Amount(
    val value: Double = 0.0
)
